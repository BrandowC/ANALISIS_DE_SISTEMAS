package View;

import Entity.Implement.Person;
import Entity.Implement.User;

import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        System.out.println("Pruebas CRUD para Person y User");

        // --- Pruebas CRUD para Person ---
        Person person = new Person();
        person.setId(1L);  // Asignar un ID a la persona
        person.setFullName("Pepito Mendieta");
        person.setTypeDocument("DNI");
        person.setNumberDocument("12345678");
        person.setPhone("555-1234");

        // Guardar la persona
        person.Save(person);

        // Consultar todas las personas
        List<Object> persons = person.All();
        System.out.println("Personas guardadas: " + persons);

        // Buscar persona por ID
        Optional<Object> foundPerson = person.FindById(1L);
        foundPerson.ifPresent(p -> System.out.println("Persona encontrada: " + ((Person) p).getFullName()));

        // Actualizar persona
        Person updatedPerson = new Person();
        updatedPerson.setFullName("Pepito Actualizado");
        updatedPerson.setPhone("555-5678");
        person.Update(updatedPerson, 1L);

        // Eliminar persona por ID
        person.DeleteById(1L);
        System.out.println("Persona eliminada con ID: 1");

        // --- Pruebas CRUD para User ---
        User user = new User();
        user.setId(10L);  // Asignar un ID al usuario
        user.setUser("pepito123");
        user.setPassword("password123");
        user.setPersonId(person);  // Asociar la persona creada al usuario

        // Guardar el usuario
        user.Save(user);

        // Consultar todos los usuarios
        List<Object> users = user.All();
        System.out.println("Usuarios guardados: " + users);

        // Buscar usuario por ID
        Optional<Object> foundUser = user.FindById(10L);
        foundUser.ifPresent(u -> System.out.println("Usuario encontrado: " + ((User) u).getUser()));

        // Actualizar usuario
        User updatedUser = new User();
        updatedUser.setUser("pepito456");
        updatedUser.setPassword("newpassword456");
        user.Update(updatedUser, 10L);

        // Eliminar usuario por ID
        user.DeleteById(10L);
        System.out.println("Usuario eliminado con ID: 10");
    }
}
