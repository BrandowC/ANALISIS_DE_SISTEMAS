package Entity.Implement;

import Entity.Abtract.ABaseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class User extends ABaseEntity {
    private String user;
    private String password;
    private Person personId;

    private static List<User> userList = new ArrayList<>();

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Person getPersonId() {
        return personId;
    }

    public void setPersonId(Person personId) {
        this.personId = personId;
    }

    @Override
    public Object Save(Object object) {
        User user = (User) object;
        userList.add(user);
        System.out.println("Usuario agregado: " + user.getUser());
        return user;
    }

    @Override
    public void Update(Object object, Long id) {
        User updatedUser = (User) object;
        Optional<User> existingUser = FindById(id).map(obj -> (User) obj); // Corregido

        if (existingUser.isPresent()) {
            User user = existingUser.get();
            user.setUser(updatedUser.getUser());
            user.setPassword(updatedUser.getPassword());
            user.setPersonId(updatedUser.getPersonId());
            System.out.println("Usuario actualizado: " + user.getUser());
        } else {
            System.out.println("Usuario no encontrado con el ID: " + id);
        }
    }


    @Override
    public List<Object> All() {
        return new ArrayList<>(userList);
    }

    @Override
    public Optional<Object> FindById(Long id) {
        return userList.stream()
                .filter(user -> user.getId().equals(id))
                .findFirst()
                .map(user -> (Object) user);
    }

    @Override
    public void DeleteById(Long id) {
        userList.removeIf(user -> user.getId().equals(id));
        System.out.println("Usuario eliminado con ID: " + id);
    }
}
