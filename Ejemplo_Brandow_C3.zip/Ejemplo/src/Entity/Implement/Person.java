package Entity.Implement;

import Entity.Abtract.ABaseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Person extends ABaseEntity {
    private String typeDocument;
    private String numberDocument;
    private String fullName;
    private String phone;

    private static List<Person> personList = new ArrayList<>();

    public String getTypeDocument() {
        return typeDocument;
    }

    public void setTypeDocument(String typeDocument) {
        this.typeDocument = typeDocument;
    }

    public String getNumberDocument() {
        return numberDocument;
    }

    public void setNumberDocument(String numberDocument) {
        this.numberDocument = numberDocument;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public Object Save(Object object) {
        Person person = (Person) object;
        personList.add(person);
        System.out.println("Persona agregada: " + person.getFullName());
        return person;
    }

    @Override
    public void Update(Object object, Long id) {
        Person updatedPerson = (Person) object;
        Optional<Person> existingPerson = FindById(id).map(obj -> (Person) obj); // Corregido

        if (existingPerson.isPresent()) {
            Person person = existingPerson.get();
            person.setFullName(updatedPerson.getFullName());
            person.setPhone(updatedPerson.getPhone());
            person.setTypeDocument(updatedPerson.getTypeDocument());
            person.setNumberDocument(updatedPerson.getNumberDocument());
            System.out.println("Persona actualizada: " + person.getFullName());
        } else {
            System.out.println("Persona no encontrada con el ID: " + id);
        }
    }


    @Override
    public List<Object> All() {
        return new ArrayList<>(personList);
    }

    @Override
    public Optional<Object> FindById(Long id) {
        return personList.stream()
                .filter(person -> person.getId().equals(id))
                .findFirst()
                .map(person -> (Object) person);
    }

    @Override
    public void DeleteById(Long id) {
        personList.removeIf(person -> person.getId().equals(id));
        System.out.println("Persona eliminada con ID: " + id);
    }
}
