## Sistema de Gestión de Hotel

### Diagrama de Clases

```plantuml
@startuml
class Cliente {
    - id_cliente: entero
    - nombre_completo: cadena
    - email: cadena
    - telefono: cadena
    + registrar()
    + iniciarSesion()
}

class Habitacion {
    - id_habitacion: entero
    - tipo_habitacion: cadena
    - precio_noche: flotante
    - disponibilidad: booleano
    + verificarDisponibilidad(): booleano
    + reservar()
}

class Reserva {
    - id_reserva: entero
    - id_cliente: entero
    - id_habitacion: entero
    - fecha_entrada: fecha
    - fecha_salida: fecha
    + crearReserva()
    + cancelarReserva()
}

class Factura {
    - id_factura: entero
    - id_reserva: entero
    - total: flotante
    + generarFactura()
}

Cliente "1" --> "0..*" Reserva
Reserva "1" --> "1" Habitacion
Reserva "1" --> "1" Factura
@enduml
```

## Explicacion

**1. Cliente**
    **Atributos:**

`id_cliente:` Identificador único del cliente.
`nombre_completo:` Nombre completo del cliente.
`email:` Correo electrónico del cliente.
``telefono:`` Número de contacto del cliente.
    **Métodos:**
``registrar():`` Permite al cliente registrarse en el sistema.
``iniciarSesion():`` Permite al cliente iniciar sesión en su cuenta.
**2. Habitacion**
    **Atributos:**
``id_habitacion:`` Identificador único de la habitación.
``tipo_habitacion:`` Tipo de habitación (simple, doble, suite, etc.).
``precio_noche:`` Precio por noche de la habitación.
``disponibilidad:`` Estado de disponibilidad de la habitación (disponible/no disponible).
    **Métodos:**
``verificarDisponibilidad():`` Verifica si la habitación está disponible.
``reservar():`` Reserva la habitación si está disponible.
**3. Reserva**
    **Atributos:**
``id_reserva:`` Identificador único de la reserva.
``id_cliente:`` Identificador del cliente que realiza la reserva.
``id_habitacion:`` Identificador de la habitación reservada.
``fecha_entrada:`` Fecha de entrada del cliente.
``fecha_salida:`` Fecha de salida del cliente.
    **Métodos:**
``crearReserva():`` Crea una nueva reserva en el sistema.
``cancelarReserva():`` Cancela una reserva existente.
**4. Factura**
    **Atributos:**
``id_factura:`` Identificador único de la factura.
`id_reserva:` Identificador de la reserva correspondiente a la factura.
``total:`` Total a pagar por la estancia.
    **Métodos:**
`generarFactura():` Genera la factura final para el cliente.