# Sistemas de Gestion de Citas

---
### Brandow S. Claros Polania
---

```plantuml
@startuml
class Paciente {
    - id_paciente: int
    - nombre: string
    - edad: int
    - email: string
    + registrarse()
    + iniciarSesion()
}

class Doctor {
    - id_doctor: int
    - nombre: string
    - especialidad: string
    + verHorarios()
    + confirmarCita()
}

class Cita {
    - id_cita: int
    - fecha: Date
    - hora: Time
    - id_paciente: int
    - id_doctor: int
    + agendarCita()
    + cancelarCita()
}

class Factura {
    - id_factura: int
    - id_cita: int
    - monto: float
    - estado_pago: string
    + generarFactura()
    + verificarPago()
}

Paciente "1" --> "1..*" Cita
Doctor "1" --> "1..*" Cita
Cita "1" --> "1" Factura
@enduml
```
### Explicacion

#### Paciente
- **Atributos**:
  - `id_paciente`: Identificador único del paciente.
  - `nombre`: Nombre completo del paciente.
  - `edad`: Edad del paciente.
  - `email`: Correo electrónico para notificaciones.
- **Métodos**:
  - `registrarse()`: Permite al paciente crear una cuenta en el sistema.
  - `iniciarSesion()`: Permite al paciente acceder a su cuenta.

#### Doctor
- **Atributos**:
  - `id_doctor`: Identificador único del doctor.
  - `nombre`: Nombre completo del doctor.
  - `especialidad`: Área de especialización.
- **Métodos**:
  - `verHorarios()`: Muestra los horarios disponibles del doctor.
  - `confirmarCita()`: Permite al doctor confirmar una cita.

#### Cita
- **Atributos**:
  - `id_cita`: Identificador único de la cita.
  - `fecha`: Fecha programada para la cita.
  - `hora`: Hora de la cita.
  - `id_paciente`: Referencia al paciente que programó la cita.
  - `id_doctor`: Referencia al doctor que atenderá la cita.
- **Métodos**:
  - `agendarCita()`: Programa una nueva cita.
  - `cancelarCita()`: Cancela una cita existente.

#### Factura
- **Atributos**:
  - `id_factura`: Identificador único de la factura.
  - `id_cita`: Referencia a la cita correspondiente.
  - `monto`: Monto total a pagar.
  - `estado_pago`: Estado del pago (pagado o pendiente).
- **Métodos**:
  - `generarFactura()`: Genera una factura para la cita.
  - `verificarPago()`: Verifica si la factura ha sido pagada.