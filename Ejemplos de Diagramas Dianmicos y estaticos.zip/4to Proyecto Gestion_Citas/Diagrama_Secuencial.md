# Diagrama De sistemas de citas Secuencial 

```plantuml

@startuml
actor Paciente
participant "Sistema de Gestión" as Sistema
participant "Cita" as Cita
participant "Doctor" as Doctor
participant "Factura" as Factura

Paciente -> Sistema: registrarse()
Sistema -> Paciente: confirmación de registro

Paciente -> Sistema: iniciarSesion()
Sistema -> Paciente: confirmación de inicio de sesión

Paciente -> Sistema: buscarDoctor(especialidad)
Sistema -> Doctor: verHorarios()
Doctor -> Sistema: horarios disponibles
Sistema -> Paciente: mostrarHorarios()

Paciente -> Sistema: agendarCita(id_doctor, fecha, hora)
Sistema -> Cita: crearCita()
Cita -> Sistema: confirmación de cita
Sistema -> Paciente: confirmación de cita

Paciente -> Sistema: solicitarFactura(id_cita)
Sistema -> Factura: generarFactura()
Factura -> Sistema: total
Sistema -> Paciente: enviarFactura(total)
@enduml
```

### Explicacion de Diagrama de Secuencia

1. **Registro de Paciente**: 
   - El paciente inicia el proceso llamando al método `registrarse()`.
   - El sistema confirma el registro, almacenando la información del paciente.

2. **Inicio de Sesión**: 
   - El paciente llama al método `iniciarSesion()`.
   - El sistema valida las credenciales y envía una confirmación de inicio de sesión.

3. **Búsqueda de Doctor**: 
   - El paciente busca doctores disponibles por especialidad.
   - El sistema llama al método `verHorarios()` en la clase `Doctor` para obtener la disponibilidad.

4. **Mostrar Horarios**: 
   - Una vez obtenida la disponibilidad de horarios, el sistema muestra al paciente los horarios disponibles para el doctor.

5. **Agendar Cita**: 
   - El paciente elige un horario y llama al método `agendarCita()`.
   - El sistema crea una nueva cita y confirma la acción.

6. **Generación de Factura**: 
   - Después de la cita, el paciente solicita la factura mediante el método `solicitarFactura()`.
   - El sistema genera y envía la factura con el total a pagar.