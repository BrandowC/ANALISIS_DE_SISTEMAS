# Sistemas de secuencia de pedidos de un Restaurante
---

```plantuml
@startuml
actor Cliente
participant "Sistema de Gestión" as Sistema
participant "Mesa" as Mesa
participant "Pedido" as Pedido
participant "Cocinero" as Cocinero

Cliente -> Sistema: hacerReserva(fecha, hora, capacidad)
Sistema -> Mesa: reservar()
Mesa -> Sistema: confirmación de reserva
Sistema -> Cliente: confirmación de reserva

Cliente -> Sistema: realizarPedido(id_mesa)
Sistema -> Pedido: crearPedido()
Pedido -> Sistema: confirmación de pedido
Sistema -> Cliente: confirmar pedido

Cliente -> Sistema: agregarPlato(id_pedido, id_plato)
Sistema -> Pedido: agregarPlato()
Pedido -> Sistema: actualización de pedido

Sistema -> Cocinero: notificar pedido
Cocinero -> Sistema: confirmar preparación
Sistema -> Cliente: notificar que el pedido está listo
@enduml
```
### Explicacion del Diagrama de Secuencia

1. **Hacer Reserva:** 
   - El cliente inicia el proceso llamando al método `hacerReserva(fecha, hora, capacidad)`. 
   - El sistema llama a la clase `Mesa` para reservarla y confirma la reserva al cliente.

2. **Realizar Pedido:** 
   - El cliente realiza un pedido usando `realizarPedido(id_mesa)`. 
   - El sistema crea un nuevo pedido y confirma al cliente.

3. **Agregar Plato:** 
   - El cliente agrega un plato al pedido mediante `agregarPlato(id_pedido, id_plato)`. 
   - El sistema actualiza el pedido.

4. **Notificación al Cocinero:** 
   - El sistema notifica al cocinero sobre el pedido. 
   - Una vez preparado, el cocinero confirma la preparación, y el sistema notifica al cliente que su pedido está listo.