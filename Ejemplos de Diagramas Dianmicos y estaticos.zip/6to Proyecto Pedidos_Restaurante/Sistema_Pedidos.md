# Sitemas de Pedidos de un Restaurante

---

```plantuml
@startuml
class Cliente {
    +id_cliente: int
    +nombre: String
    +telefono: String
    +hacerReserva(): void
}

class Mesa {
    +id_mesa: int
    +capacidad: int
    +estado: String
    +reservar(): void
}

class Pedido {
    +id_pedido: int
    +id_cliente: int
    +id_mesa: int
    +estado: String
    +agregarPlato(plato: Plato): void
    +finalizar(): void
}

class Plato {
    +id_plato: int
    +nombre: String
    +precio: float
}

Cliente "1" -- "0..*" Pedido : realiza >
Mesa "1" -- "0..*" Pedido : ocupa >
Pedido "0..*" -- "1" Plato : contiene >
@enduml
```
## Explicacion de Diagrama de Clases

### Cliente
- **Atributos:**
  - `id_cliente`: Identificador único del cliente.
  - `nombre`: Nombre del cliente.
  - `telefono`: Número de teléfono del cliente.
- **Métodos:**
  - `hacerReserva()`: Permite al cliente hacer una reserva de mesa.

### Mesa
- **Atributos:**
  - `id_mesa`: Identificador único de la mesa.
  - `capacidad`: Capacidad de la mesa (número de personas).
  - `estado`: Estado de la mesa (disponible, reservada).
- **Métodos:**
  - `reservar()`: Reserva la mesa para un cliente.

### Pedido
- **Atributos:**
  - `id_pedido`: Identificador único del pedido.
  - `id_cliente`: Referencia al cliente que realiza el pedido.
  - `id_mesa`: Referencia a la mesa ocupada por el pedido.
  - `estado`: Estado del pedido (en preparación, servido).
- **Métodos:**
  - `agregarPlato(plato: Plato)`: Agrega un plato al pedido.
  - `finalizar()`: Finaliza el pedido.

### Plato
- **Atributos:**
  - `id_plato`: Identificador único del plato.
  - `nombre`: Nombre del plato.
  - `precio`: Precio del plato.