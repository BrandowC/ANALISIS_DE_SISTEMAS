### Sistemas de Inventario de Local-"Motos"

---

```plantuml
@startuml
actor Almacenista
participant "Sistema de Inventario" as Sistema
participant "Producto" as Producto
participant "Pedido" as Pedido
participant "Proveedor" as Proveedor

Almacenista -> Sistema: iniciarSesion()
Sistema -> Almacenista: confirmación de inicio de sesión

Almacenista -> Sistema: buscarProducto(nombre)
Sistema -> Producto: verificarDisponibilidad()
Producto -> Sistema: disponibilidad
Sistema -> Almacenista: mostrarProductosDisponibles()

Almacenista -> Sistema: realizarPedido(id_producto, cantidad)
Sistema -> Pedido: crearPedido()
Pedido -> Proveedor: enviarSolicitudPedido()
Proveedor -> Pedido: confirmación de pedido
Sistema -> Almacenista: confirmación de pedido

Almacenista -> Sistema: actualizarStock(id_producto, cantidad)
Sistema -> Producto: actualizarStock(cantidad)
Producto -> Sistema: confirmación de actualización
Sistema -> Almacenista: confirmación de actualización
@enduml
```

### Explicacion de Diagrama 

- **Inicio de Sesión**: El almacenista inicia sesión en el sistema llamando al método `iniciarSesion()`. El sistema confirma el inicio de sesión.

- **Búsqueda de Producto**: El almacenista busca un producto específico utilizando `buscarProducto(nombre)`. El sistema llama al método `verificarDisponibilidad()` de la clase Producto para verificar si el producto está disponible, y luego muestra los productos disponibles al almacenista.

- **Realización de Pedido**: El almacenista realiza un pedido para reabastecer el inventario utilizando `realizarPedido(id_producto, cantidad)`. El sistema crea un nuevo pedido y lo envía al proveedor correspondiente, quien confirma la solicitud.

- **Actualización de Stock**: Después de recibir el producto, el almacenista actualiza el stock del producto en el inventario usando `actualizarStock(id_producto, cantidad)`. El sistema actualiza la cantidad en la clase Producto y confirma la actualización al almacenista.