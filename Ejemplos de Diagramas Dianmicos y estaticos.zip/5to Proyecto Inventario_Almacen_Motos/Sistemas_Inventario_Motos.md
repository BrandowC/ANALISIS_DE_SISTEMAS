# Sitemas de Inventario de un almacen-"motos"

---
Brandow S. Claros Polania
---

```plantuml
@startuml
class Producto {
  - id_producto: int
  - nombre: String
  - precio: float
  - stock: int
  + actualizarStock(cantidad: int): void
}

class Categoria {
  - id_categoria: int
  - nombre: String
  + agregarProducto(producto: Producto): void
}

class Proveedor {
  - id_proveedor: int
  - nombre: String
  - telefono: String
  + solicitarPedido(producto: Producto, cantidad: int): void
}

class Pedido {
  - id_pedido: int
  - fecha: Date
  - estado: String
  + procesarPedido(): void
  + cancelarPedido(): void
}

Producto "1" -- "*" Categoria
Producto "1" -- "*" Pedido
Pedido "*" -- "1" Proveedor
@enduml

```

### Explicacion 

