### SISTEMA DE CLÍNICA VETERINARIA###
---
## Brandow S. Claros Polania

Este sistema se implementará con diferentes clases para gestionar las entidades de Mascota, Cliente, Veterinario, Consulta y Medicamento.

### Diagrama de Clases

```plantuml
@startuml
class Mascota {
    - id_mascota: entero
    - nombre: cadena
    - especie: cadena
    - raza: cadena
    - edad: entero
    + registrarMascota()
    + actualizarDatos()
}

class Cliente {
    - id_cliente: entero
    - nombre_completo: cadena
    - telefono: cadena
    - email: cadena
    + registrarCliente()
    + actualizarContacto()
}

class Veterinario {
    - id_veterinario: entero
    - nombre_completo: cadena
    - especialidad: cadena
    + realizarConsulta(mascota: Mascota, diagnostico: cadena)
}

class Consulta {
    - id_consulta: entero
    - id_mascota: entero
    - id_veterinario: entero
    - fecha: fecha
    - diagnostico: cadena
    + registrarConsulta()
}

class Medicamento {
    - id_medicamento: entero
    - nombre: cadena
    - dosis: cadena
    + administrarMedicamento()
}

Cliente "1" --> "1..*" Mascota
Veterinario "1" --> "1..*" Consulta
Consulta "1" --> "1" Mascota
Consulta "1" --> "1" Veterinario
Consulta "1" --> "1..*" Medicamento
@enduml
```

## Explicacion del Diagrama de CLases
1. Mascota

Atributos:

id_mascota: Identificador único de la mascota.
nombre: Nombre de la mascota.
especie: Especie a la que pertenece.
raza: Raza de la mascota.
edad: Edad de la mascota.
Métodos:

registrarMascota(): Registra una nueva mascota.
actualizarDatos(): Actualiza los datos de la mascota.
2. Cliente

Atributos:

id_cliente: Identificador único del cliente.
nombre_completo: Nombre completo del cliente.
telefono: Número de contacto.
email: Correo electrónico.
Métodos:

registrarCliente(): Registra un nuevo cliente.
actualizarContacto(): Actualiza la información de contacto del cliente.
3. Veterinario

Atributos:

id_veterinario: Identificador único del veterinario.
nombre_completo: Nombre completo del veterinario.
especialidad: Especialidad del veterinario.
Métodos:

realizarConsulta(mascota: Mascota, diagnostico: cadena): Realiza una consulta médica.
4. Consulta

Atributos:

id_consulta: Identificador único de la consulta.
id_mascota: Referencia a la mascota consultada.
id_veterinario: Referencia al veterinario que atendió la consulta.
fecha: Fecha de la consulta.
diagnostico: Diagnóstico proporcionado.
Métodos:

registrarConsulta(): Registra una nueva consulta.
5. Medicamento

Atributos:

id_medicamento: Identificador único del medicamento.
nombre: Nombre del medicamento.
dosis: Dosis recomendada.
Métodos:

administrarMedicamento(): Administra el medicamento a la mascota.