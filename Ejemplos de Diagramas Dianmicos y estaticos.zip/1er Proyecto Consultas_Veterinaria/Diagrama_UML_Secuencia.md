
### Diagrama de Secuencia
```plantuml
startuml
actor Cliente
participant "Veterinario" as Veterinario
participant "Consulta" as Consulta
participant "Mascota" as Mascota
participant "Medicamento" as Medicamento

Cliente -> Mascota: registrarMascota()
Cliente -> Veterinario: solicitarConsulta(mascota)
Veterinario -> Consulta: registrarConsulta()
Consulta -> Veterinario: realizarConsulta(mascota, diagnostico)
Veterinario -> Medicamento: administrarMedicamento()
Medicamento --> Consulta: confirmarAdministracion()
Consulta --> Cliente: enviarInforme(diagnostico)
@enduml
```

## Explicación del Diagrama Dinámico

El diagrama de secuencia representa el flujo de interacción entre los actores y los componentes del sistema durante el proceso de registro de una consulta veterinaria. Aquí está el desglose de cada interacción:

1. **Cliente registra mascota**: El cliente inicia el proceso llamando al método `registrarMascota()`, donde se ingresan los datos de la mascota en el sistema.
   
2. **Cliente solicita consulta**: Luego, el cliente solicita una consulta para su mascota, enviando el mensaje `solicitarConsulta(mascota)` al veterinario. Esta acción puede incluir la selección de la mascota previamente registrada.

3. **Veterinario registra consulta**: El veterinario recibe la solicitud y llama al método `registrarConsulta()` en el objeto Consulta para crear un nuevo registro.

4. **Veterinario realiza consulta**: El veterinario a continuación llama al método `realizarConsulta(mascota, diagnostico)` para proceder con la atención de la mascota, donde se realizan las evaluaciones necesarias.

5. **Veterinario administra medicamento**: Después de proporcionar el diagnóstico, el veterinario puede necesitar administrar un medicamento, por lo que se llama a `administrarMedicamento()` en el objeto Medicamento.

6. **Confirmación de administración**: Una vez administrado el medicamento, el Medicamento envía una confirmación de que la administración ha sido exitosa, regresando a la Consulta.

7. **Envío de informe**: Finalmente, el sistema envía un informe al cliente que incluye el diagnóstico y cualquier recomendación a seguir.
