### Sistema de Gestión de una Biblioteca

```plantuml
@startuml
class Libro {
    - id_libro: entero
    - titulo: cadena
    - autor: cadena
    - isbn: cadena
    - disponibilidad: booleano
    + prestar()
    + devolver()
}

class Usuario {
    - id_usuario: entero
    - nombre: cadena
    - email: cadena
    + registrarse()
    + iniciarSesion()
}

class Prestamo {
    - id_prestamo: entero
    - id_libro: entero
    - id_usuario: entero
    - fecha_prestamo: fecha
    - fecha_devolucion: fecha
    + crearPrestamo()
    + finalizarPrestamo()
}

Usuario "1" --> "*" Prestamo
Libro "1" --> "*" Prestamo
@enduml
```
## Explicacion del Diagrama

### Libro
- **Atributos:**
  - `id_libro`: Identificador único del libro.
  - `titulo`: Título del libro.
  - `autor`: Autor del libro.
  - `isbn`: Número de ISBN del libro.
  - `disponibilidad`: Indica si el libro está disponible para préstamo.

- **Métodos:**
  - `prestar()`: Método para prestar el libro.
  - `devolver()`: Método para devolver el libro.

### Usuario
- **Atributos:**
  - `id_usuario`: Identificador único del usuario.
  - `nombre`: Nombre del usuario.
  - `email`: Correo electrónico del usuario.

- **Métodos:**
  - `registrarse()`: Método para registrar un nuevo usuario.
  - `iniciarSesion()`: Método para iniciar sesión en el sistema.

### Préstamo
- **Atributos:**
  - `id_prestamo`: Identificador único del préstamo.
  - `id_libro`: Referencia al libro prestado.
  - `id_usuario`: Referencia al usuario que realizó el préstamo.
  - `fecha_prestamo`: Fecha en que se realizó el préstamo.
  - `fecha_devolucion`: Fecha en que se devolverá el libro.

- **Métodos:**
  - `crearPrestamo()`: Método para crear un nuevo préstamo.
  - `finalizarPrestamo()`: Método para finalizar el préstamo.
