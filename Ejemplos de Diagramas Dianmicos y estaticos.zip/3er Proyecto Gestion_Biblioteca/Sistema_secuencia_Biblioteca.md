### Diagrama Secuencial de Gestion de una Biblioteca

Brandow Stivent Claros Polania
----
Con este sistema de gestión para la biblioteca, se busca facilitar el proceso de administración de libros y usuarios, permitiendo un control eficiente de los préstamos y devoluciones.

```plantuml
@startuml
actor Usuario
participant "Sistema de Gestión" as Sistema
participant "Libro" as Libro
participant "Préstamo" as Prestamo

Usuario -> Sistema: registrarse()
Sistema -> Usuario: confirmación de registro

Usuario -> Sistema: iniciarSesion()
Sistema -> Usuario: confirmación de inicio de sesión

Usuario -> Sistema: buscarLibro(titulo)
Sistema -> Libro: verificarDisponibilidad()
Libro -> Sistema: disponibilidad
Sistema -> Usuario: mostrarLibros()

Usuario -> Sistema: prestarLibro(id_libro)
Sistema -> Prestamo: crearPrestamo()
Prestamo -> Sistema: confirmación de préstamo
Sistema -> Usuario: confirmación de préstamo

Usuario -> Sistema: devolverLibro(id_libro)
Sistema -> Prestamo: finalizarPrestamo()
Prestamo -> Sistema: confirmación de devolución
Sistema -> Usuario: confirmación de devolución
@enduml
```
## Explicacion de Diagrama 

- **Registro de Usuario**: El usuario inicia el proceso llamando al método `registrarse()`. El sistema confirma el registro, almacenando la información del usuario.

- **Inicio de Sesión**: El usuario llama al método `iniciarSesion()`, y el sistema valida las credenciales, enviando una confirmación de inicio de sesión.

- **Búsqueda de Libros**: El usuario busca libros disponibles utilizando el método `buscarLibro(titulo)`. El sistema verifica la disponibilidad llamando a `verificarDisponibilidad()` en la clase `Libro`.

- **Mostrar Libros**: Una vez obtenida la disponibilidad, el sistema muestra los libros disponibles al usuario.

- **Préstamo de Libro**: El usuario elige un libro y llama al método `prestarLibro(id_libro)`. El sistema crea un nuevo préstamo, confirmando la acción.

- **Devolución de Libro**: El usuario solicita devolver el libro utilizando el método `devolverLibro(id_libro)`, lo que finaliza el préstamo y envía una confirmación de la devolución al usuario.
