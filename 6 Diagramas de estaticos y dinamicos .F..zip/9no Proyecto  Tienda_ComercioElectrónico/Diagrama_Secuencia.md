# Diagrama de Secuencia

```plantuml
@startuml
actor Usuario
participant "Sistema" as Sistema

== Registro de Usuario ==
Usuario -> Sistema: registrarse(nombre, email, direccion)
Sistema -> Usuario: Confirmación de registro

== Inicio de Sesión ==
Usuario -> Sistema: iniciarSesion(email)
Sistema -> Usuario: Confirmación de inicio de sesión

== Búsqueda de Producto ==
Usuario -> Sistema: buscarProductos(filtro)
Sistema -> Usuario: Devuelve lista de productos

== Agregar Producto al Carrito ==
Usuario -> Sistema: agregarAlCarrito(producto)
Sistema -> Usuario: Actualiza carrito

== Realizar Pedido ==
Usuario -> Sistema: procesarPedido()
Sistema -> Usuario: Confirma creación del pedido
@enduml
```

### Explicacion

#### Proceso de Compra

1. **Registro de Usuario:**
   - Usuario -> Sistema: `registrarse(nombre, email, direccion)`
   - Sistema -> Usuario: Confirmación de registro

2. **Inicio de Sesión:**
   - Usuario -> Sistema: `iniciarSesion(email)`
   - Sistema -> Usuario: Confirmación de inicio de sesión

3. **Búsqueda de Producto:**
   - Usuario -> Sistema: `buscarProductos(filtro)`
   - Sistema -> Usuario: Devuelve lista de productos

4. **Agregar Producto al Carrito:**
   - Usuario -> Sistema: `agregarAlCarrito(producto)`
   - Sistema -> Usuario: Actualiza carrito

5. **Realizar Pedido:**
   - Usuario -> Sistema: `procesarPedido()`
   - Sistema -> Usuario: Confirma creación del pedido