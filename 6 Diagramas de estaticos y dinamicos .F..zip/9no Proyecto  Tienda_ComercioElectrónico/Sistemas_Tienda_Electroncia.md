# Sistema de una Tienda electronica

---

```plantuml
@startuml
class Usuario {
    - id_usuario: int
    - nombre: String
    - email: String
    - direccion: String
    + registrarse(): void
    + iniciarSesion(): void
    + agregarDireccion(direccion: String): void
}

class Producto {
    - id_producto: int
    - nombre: String
    - precio: float
    - stock: int
    + actualizarStock(cantidad: int): void
    + agregarAlCarrito(usuario: Usuario): void
}

class Carrito {
    - id_carrito: int
    - productos: List<Producto>
    - usuario: Usuario
    + agregarProducto(producto: Producto): void
    + eliminarProducto(producto: Producto): void
    + calcularTotal(): float
}

class Pedido {
    - id_pedido: int
    - usuario: Usuario
    - productos: List<Producto>
    - estado: String
    + procesarPedido(): void
    + cancelarPedido(): void
}

Usuario "1" -- "0..*" Carrito : posee >
Carrito "1" -- "0..*" Producto : contiene >
Usuario "1" -- "0..*" Pedido : realiza >
Pedido "1" -- "0..*" Producto : incluye >
@enduml
```

## Explicacion de Diagrama 

### Usuario
- **Atributos:**
  - `id_usuario: int`
  - `nombre: String`
  - `email: String`
  - `direccion: String`
- **Métodos:**
  - `registrarse(): void`
  - `iniciarSesion(): void`
  - `agregarDireccion(direccion: String): void`

### Producto
- **Atributos:**
  - `id_producto: int`
  - `nombre: String`
  - `precio: float`
  - `stock: int`
- **Métodos:**
  - `actualizarStock(cantidad: int): void`
  - `agregarAlCarrito(usuario: Usuario): void`

### Carrito
- **Atributos:**
  - `id_carrito: int`
  - `productos: List<Producto>`
  - `usuario: Usuario`
- **Métodos:**
  - `agregarProducto(producto: Producto): void`
  - `eliminarProducto(producto: Producto): void`
  - `calcularTotal(): float`

### Pedido
- **Atributos:**
  - `id_pedido: int`
  - `usuario: Usuario`
  - `productos: List<Producto>`
  - `estado: String`
- **Métodos:**
  - `procesarPedido(): void`
  - `cancelarPedido(): void`