# Sitemas de Gestion de un "GIM"

```plantuml
@startuml
class Cliente {
    - id_cliente: int
    - nombre: string
    - email: string
    - telefono: string
    + registrarse()
    + iniciarSesion()
}

class Entrenador {
    - id_entrenador: int
    - nombre: string
    - especialidad: string
    + verHorarios()
}

class Clase {
    - id_clase: int
    - nombre: string
    - capacidad: int
    - horarios: string
    + agregarParticipante(cliente: Cliente)
    + eliminarParticipante(cliente: Cliente)
}

class Pago {
    - id_pago: int
    - monto: float
    - estado: string
    + procesarPago()
}

Cliente "1" -- "*" Clase : inscribirse >
Entrenador "1" -- "*" Clase : impartir >
Clase "*" -- "*" Cliente : participar >
@enduml
```

## Explicacion de diagrama estatico

### Cliente

- **Atributos:**
  - `id_cliente`: Identificador único del cliente.
  - `nombre`: Nombre completo del cliente.
  - `email`: Correo electrónico del cliente.
  - `telefono`: Número de teléfono del cliente.

- **Métodos:**
  - `registrarse()`: Permite al cliente registrarse en el sistema.
  - `iniciarSesion()`: Permite al cliente acceder a su cuenta.

---

### Entrenador

- **Atributos:**
  - `id_entrenador`: Identificador único del entrenador.
  - `nombre`: Nombre completo del entrenador.
  - `especialidad`: Área de especialización del entrenador.

- **Métodos:**
  - `verHorarios()`: Muestra los horarios disponibles del entrenador.

---

### Clase

- **Atributos:**
  - `id_clase`: Identificador único de la clase.
  - `nombre`: Nombre de la clase.
  - `capacidad`: Capacidad máxima de participantes en la clase.
  - `horarios`: Horarios en que se imparte la clase.

- **Métodos:**
  - `agregarParticipante(cliente: Cliente)`: Agrega un cliente a la clase.
  - `eliminarParticipante(cliente: Cliente)`: Elimina un cliente de la clase.

---

### Pago

- **Atributos:**
  - `id_pago`: Identificador único del pago.
  - `monto`: Monto a pagar.
  - `estado`: Estado del pago (pendiente, completado).

- **Métodos:**
  - `procesarPago()`: Procesa el pago del cliente.