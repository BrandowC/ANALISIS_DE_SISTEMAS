# Diagrama de Secuencia de un Gimnasio
---
Brandow CLaros
---

```plantuml
@startuml
actor Cliente
participant "Sistema de Gestión" as Sistema
participant "Clase" as Clase
participant "Entrenador" as Entrenador
participant "Pago" as Pago

Cliente -> Sistema: registrarse(nombre, email, telefono)
Sistema -> Cliente: confirmación de registro

Cliente -> Sistema: iniciarSesion(email)
Sistema -> Cliente: confirmación de inicio de sesión

Cliente -> Sistema: buscarClases()
Sistema -> Clase: listarClasesDisponibles()
Clase -> Sistema: clases disponibles
Sistema -> Cliente: mostrarClases()

Cliente -> Sistema: inscribirseClase(id_clase)
Sistema -> Clase: agregarParticipante(cliente)
Clase -> Sistema: confirmación de inscripción
Sistema -> Cliente: confirmación de inscripción

Cliente -> Sistema: realizarPago(monto)
Sistema -> Pago: procesarPago()
Pago -> Sistema: confirmación de pago
Sistema -> Cliente: recibo de pago
@enduml
```
## Descripción del Diagrama de Secuencia

### Registro de Cliente:
1. El cliente llama al método `registrarse(nombre, email, telefono)`.
2. El sistema confirma el registro.

---

### Inicio de Sesión:
1. El cliente llama al método `iniciarSesion(email)`.
2. El sistema valida las credenciales y envía una confirmación de inicio de sesión.

---

### Búsqueda de Clases:
1. El cliente solicita buscar clases disponibles.
2. El sistema consulta a la clase y obtiene la lista de clases disponibles.

---

### Inscripción a Clase:
1. El cliente se inscribe en una clase usando `inscribirseClase(id_clase)`.
2. El sistema agrega al cliente a la clase y confirma la inscripción.

---

### Realización de Pago:
1. El cliente realiza el pago correspondiente mediante `realizarPago(monto)`.
2. El sistema procesa el pago y envía un recibo al cliente.