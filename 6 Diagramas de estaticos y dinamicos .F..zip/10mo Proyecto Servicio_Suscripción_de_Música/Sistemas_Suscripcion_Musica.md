# Sistema de Suscripcion de Musica

---

```plantuml
@startuml
class Usuario {
    - id_usuario: int
    - nombre: String
    - email: String
    - contraseña: String
    + registrar(): void
    + iniciarSesion(): void
}

class Cancion {
    - id_cancion: int
    - titulo: String
    - artista: String
    - duracion: String
    + agregarAFavoritos(): void
}

class ListaDeReproduccion {
    - id_lista: int
    - nombre: String
    - id_usuario: int
    + agregarCancion(cancion: Cancion): void
    + eliminarCancion(cancion: Cancion): void
}

class Suscripcion {
    - id_suscripcion: int
    - tipo: String
    - fecha_inicio: Date
    - fecha_fin: Date
    + renovar(): void
}

Usuario "1" -- "0..*" ListaDeReproduccion : posee >
Usuario "1" -- "1" Suscripcion : tiene >
ListaDeReproduccion "1" -- "0..*" Cancion : contiene >
@enduml
```

## Diagrama de Clases

### Usuario
- **Atributos:**
  - `id_usuario`: Identificador único del usuario.
  - `nombre`: Nombre completo del usuario.
  - `email`: Correo electrónico del usuario.
  - `contraseña`: Contraseña del usuario.
- **Métodos:**
  - `registrar()`: Permite al usuario registrarse en el sistema.
  - `iniciarSesion()`: Permite al usuario acceder a su cuenta.

### Canción
- **Atributos:**
  - `id_cancion`: Identificador único de la canción.
  - `titulo`: Título de la canción.
  - `artista`: Artista de la canción.
  - `duracion`: Duración de la canción.
- **Métodos:**
  - `agregarAFavoritos()`: Agrega la canción a la lista de favoritos del usuario.

### ListaDeReproduccion
- **Atributos:**
  - `id_lista`: Identificador único de la lista de reproducción.
  - `nombre`: Nombre de la lista de reproducción.
  - `id_usuario`: Referencia al usuario propietario de la lista.
- **Métodos:**
  - `agregarCancion(cancion: Canción)`: Agrega una canción a la lista de reproducción.
  - `eliminarCancion(cancion: Canción)`: Elimina una canción de la lista de reproducción.

### Suscripción
- **Atributos:**
  - `id_suscripcion`: Identificador único de la suscripción.
  - `tipo`: Tipo de suscripción (gratuita, premium).
  - `fecha_inicio`: Fecha de inicio de la suscripción.
  - `fecha_fin`: Fecha de finalización de la suscripción.
- **Métodos:**
  - `renovar()`: Renueva la suscripción del usuario.