# Diagrama de secuencia

---
```platnuml
@startuml
actor Usuario
participant "Sistema" as Sistema

== Registro de Usuario ==
Usuario -> Sistema: registrar(nombre, email, contraseña)
Sistema -> Usuario: Confirmación de registro

== Inicio de Sesión ==
Usuario -> Sistema: iniciarSesion(email, contraseña)
Sistema -> Usuario: Confirmación de inicio de sesión

== Búsqueda de Canciones ==
Usuario -> Sistema: buscarCanciones(filtro)
Sistema -> Usuario: Devuelve lista de canciones

== Agregar Canción a Favoritos ==
Usuario -> Sistema: agregarAFavoritos(id_cancion)
Sistema -> Usuario: Confirmación de agregado a favoritos

== Crear Lista de Reproducción ==
Usuario -> Sistema: crearLista(nombre)
Sistema -> Usuario: Confirmación de creación de lista

== Agregar Canción a la Lista ==
Usuario -> Sistema: agregarCancion(id_lista, id_cancion)
Sistema -> Usuario: Confirmación de canción agregada
@enduml
```
## Explicacion

### Registro de Usuario:
1. El usuario llama al método `registrar(nombre, email, contraseña)`.
2. El sistema confirma el registro.

### Inicio de Sesión:
1. El usuario llama al método `iniciarSesion(email, contraseña)`.
2. El sistema valida las credenciales y envía una confirmación de inicio de sesión.

### Búsqueda de Canciones:
1. El usuario solicita buscar canciones disponibles.
2. El sistema devuelve la lista de canciones disponibles.

### Agregar Canción a Favoritos:
1. El usuario agrega una canción a sus favoritos usando `agregarAFavoritos(id_cancion)`.
2. El sistema confirma la acción.

### Crear Lista de Reproducción:
1. El usuario crea una lista de reproducción mediante `crearLista(nombre)`.
2. El sistema crea la nueva lista y confirma.

### Agregar Canción a la Lista de Reproducción:
1. El usuario agrega una canción a la lista usando `agregarCancion(id_lista, id_cancion)`.
2. El sistema actualiza la lista de reproducción y confirma.