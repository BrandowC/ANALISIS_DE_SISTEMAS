# Diagrama de Secuencia

```plantuml
@startuml
actor Usuario
participant Sistema
participant Tarea

== Crear Tarea ==
Usuario -> Sistema : crearTarea(titulo, descripcion, fecha_limite)
Sistema -> Tarea : Crear nueva tarea
Sistema --> Usuario : Confirmar creación de tarea

== Actualizar Estado de Tarea ==
Usuario -> Tarea : seleccionar tarea
Usuario -> Sistema : actualizarEstado(id_tarea, nuevo_estado)
Sistema -> Tarea : Actualizar estado
Sistema --> Usuario : Confirmar actualización de estado

== Ver Tareas de Proyecto ==
Usuario -> Sistema : verTareas(id_proyecto)
Sistema -> Tarea : Consultar tareas del proyecto
Sistema --> Usuario : Mostrar lista de tareas

== Eliminar Tarea ==
Usuario -> Tarea : seleccionar tarea para eliminar
Usuario -> Sistema : eliminarTarea(id_tarea)
Sistema -> Tarea : Eliminar tarea
Sistema --> Usuario : Confirmar eliminación de tarea
@enduml

```

## Explicacion de Diagrama

### Crear Tarea:
1. El usuario llama al método `crearTarea(titulo, descripcion, fecha_limite)`.
2. El sistema crea una nueva tarea y confirma la creación al usuario.

---

### Actualizar Estado de Tarea:
1. El usuario selecciona una tarea existente.
2. El usuario llama al método `actualizarEstado(id_tarea, nuevo_estado)`.
3. El sistema actualiza el estado de la tarea y envía una confirmación al usuario.

---

### Ver Tareas de Proyecto:
1. El usuario solicita ver las tareas de un proyecto utilizando `verTareas(id_proyecto)`.
2. El sistema consulta las tareas del proyecto y muestra la lista al usuario.

---

### Eliminar Tarea:
1. El usuario selecciona una tarea para eliminar.
2. El usuario llama al método `eliminarTarea(id_tarea)`.
3. El sistema elimina la tarea y confirma la acción al usu