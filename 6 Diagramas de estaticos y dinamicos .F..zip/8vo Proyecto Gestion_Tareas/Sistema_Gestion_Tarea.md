# Sistema de Gestion de Tareas
---

```plantuml
@startuml
class Tarea {
    - id_tarea: int
    - titulo: String
    - descripcion: String
    - fecha_limite: Date
    - estado: String
    + crearTarea(): void
    + actualizarEstado(estado: String): void
    + eliminarTarea(): void
}

class Usuario {
    - id_usuario: int
    - nombre: String
    - email: String
    + registrar(): void
    + iniciarSesion(): void
}

class Proyecto {
    - id_proyecto: int
    - nombre: String
    - descripcion: String
    - fecha_inicio: Date
    - fecha_fin: Date
    + agregarTarea(tarea: Tarea): void
    + eliminarTarea(tarea: Tarea): void
    + verTareas(): List<Tarea>
}

Usuario "1" --> "*" Tarea : "asigna"
Proyecto "1" --> "*" Tarea : "contiene"
@enduml

```

## Explicacion de Diagrama de clases

### Tarea
- **Atributos:**
  - `id_tarea`: Identificador único de la tarea.
  - `titulo`: Título de la tarea.
  - `descripcion`: Descripción detallada de la tarea.
  - `fecha_limite`: Fecha límite para completar la tarea.
  - `estado`: Estado de la tarea (pendiente, en progreso, completada).

- **Métodos:**
  - `crearTarea()`: Crea una nueva tarea.
  - `actualizarEstado(estado: str)`: Actualiza el estado de la tarea.
  - `eliminarTarea()`: Elimina la tarea.

---

### Usuario
- **Atributos:**
  - `id_usuario`: Identificador único del usuario.
  - `nombre`: Nombre completo del usuario.
  - `email`: Correo electrónico del usuario.

- **Métodos:**
  - `registrar()`: Permite al usuario registrarse en el sistema.
  - `iniciarSesion()`: Permite al usuario iniciar sesión en el sistema.

---

### Proyecto
- **Atributos:**
  - `id_proyecto`: Identificador único del proyecto.
  - `nombre`: Nombre del proyecto.
  - `descripcion`: Descripción del proyecto.
  - `fecha_inicio`: Fecha de inicio del proyecto.
  - `fecha_fin`: Fecha de finalización del proyecto.

- **Métodos:**
  - `agregarTarea(tarea: Tarea)`: Agrega una tarea al proyecto.
  - `eliminarTarea(tarea: Tarea)`: Elimina una tarea del proyecto.
  - `verTareas()`: Muestra todas las tareas del proyecto.