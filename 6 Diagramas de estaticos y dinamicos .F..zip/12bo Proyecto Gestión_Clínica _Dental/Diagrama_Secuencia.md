# Diagrama de Secuencia
----

```plantuml
@startuml

actor Paciente
participant "Sistema de Clínica Dental" as Sistema
participant "Cita" as Cita
participant "Dentista" as Dentista
participant "Tratamiento" as Tratamiento

== Registro de Paciente ==
Paciente -> Sistema: registrar(nombre, email, telefono)
Sistema -> Paciente: confirmación de registro

== Inicio de Sesión ==
Paciente -> Sistema: iniciarSesion(email, contraseña)
Sistema -> Paciente: confirmación de inicio de sesión

== Agendar Cita ==
Paciente -> Sistema: agendarCita(id_dentista, fecha, hora)
Sistema -> Cita: agendar()
Cita --> Sistema: confirmación de agendado
Sistema -> Paciente: confirmación de cita

== Consultar Tratamientos ==
Paciente -> Sistema: consultarTratamientos()
Sistema -> Tratamiento: listarTratamientos()
Tratamiento --> Sistema: lista de tratamientos
Sistema -> Paciente: mostrarTratamientos()

== Realizar Tratamiento ==
Paciente -> Sistema: realizarTratamiento(id_tratamiento)
Sistema -> Tratamiento: realizar()
Tratamiento --> Sistema: confirmación de tratamiento
Sistema -> Paciente: confirmación de tratamiento realizado

@enduml
```

### Explicacion

1. **Registro de Paciente:**
   - El paciente llama al método `registrar(nombre, email, telefono)`.
   - El sistema confirma el registro y devuelve un mensaje de confirmación al paciente.

2. **Inicio de Sesión:**
   - El paciente llama al método `iniciarSesion(email, contraseña)`.
   - El sistema valida las credenciales y envía una confirmación de inicio de sesión al paciente.

3. **Agendar Cita:**
   - El paciente llama al método `agendarCita(id_dentista, fecha, hora)`.
   - El sistema llama a la clase `Cita` y ejecuta el método `agendar()`.
   - La cita se agenda y el sistema confirma la cita al paciente.

4. **Consultar Tratamientos:**
   - El paciente solicita consultar tratamientos disponibles llamando al método `consultarTratamientos()`.
   - El sistema devuelve una lista de tratamientos disponibles al paciente.

5. **Realizar Tratamiento:**
   - El paciente llama al método `realizarTratamiento(id_tratamiento)`.
   - El sistema llama a la clase `Tratamiento` y ejecuta el método `realizar()`.
   - El tratamiento se realiza y el sistema confirma que el tratamiento ha sido completado.
