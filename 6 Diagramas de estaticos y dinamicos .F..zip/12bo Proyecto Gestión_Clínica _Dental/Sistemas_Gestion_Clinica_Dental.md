# Sitemas de Gestion de una clinica Dental

---
```plantuml

@startuml
class Paciente {
    - id_paciente: int
    - nombre: string
    - email: string
    - telefono: string
    + registrar(): void
    + iniciarSesion(): void
}

class Dentista {
    - id_dentista: int
    - nombre: string
    - especialidad: string
    + consultarPacientes(): void
}

class Cita {
    - id_cita: int
    - id_paciente: int
    - id_dentista: int
    - fecha: Date
    - hora: Time
    + agendar(): void
    + cancelar(): void
}

class Tratamiento {
    - id_tratamiento: int
    - descripcion: string
    - costo: float
    + realizar(): void
}
@enduml

```

### Explicacion de Clases

- **Paciente**
  - **Atributos:**
    - `id_paciente`: Identificador único del paciente.
    - `nombre`: Nombre completo del paciente.
    - `email`: Correo electrónico del paciente.
    - `telefono`: Número de teléfono del paciente.
  - **Métodos:**
    - `registrar()`: Permite al paciente registrarse en el sistema.
    - `iniciarSesion()`: Permite al paciente acceder a su cuenta.

- **Dentista**
  - **Atributos:**
    - `id_dentista`: Identificador único del dentista.
    - `nombre`: Nombre completo del dentista.
    - `especialidad`: Área de especialización del dentista.
  - **Métodos:**
    - `consultarPacientes()`: Muestra la lista de pacientes del dentista.

- **Cita**
  - **Atributos:**
    - `id_cita`: Identificador único de la cita.
    - `id_paciente`: Referencia al paciente que tiene la cita.
    - `id_dentista`: Referencia al dentista asignado a la cita.
    - `fecha`: Fecha de la cita.
    - `hora`: Hora de la cita.
  - **Métodos:**
    - `agendar()`: Agenda la cita en el sistema.
    - `cancelar()`: Cancela la cita.

- **Tratamiento**
  - **Atributos:**
    - `id_tratamiento`: Identificador único del tratamiento.
    - `descripcion`: Descripción del tratamiento.
    - `costo`: Costo del tratamiento.
  - **Métodos:**
    - `realizar()`: Realiza el tratamiento al paciente.
