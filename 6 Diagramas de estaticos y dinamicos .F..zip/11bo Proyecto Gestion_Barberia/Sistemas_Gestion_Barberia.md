# Sistema de Gestion de una Barberia

---
Brandow Claros
---
```plantuml
@startuml

class Cliente {
  - id_cliente: int
  - nombre: string
  - telefono: string
  - email: string
  + registrarse(): void
  + reservarCita(): void
}

class Barberia {
  - id_barberia: int
  - nombre: string
  - direccion: string
  - telefono: string
  + agregarBarbero(barbero: Barbero): void
  + listarBarberos(): void
}

class Barbero {
  - id_barbero: int
  - nombre: string
  - especialidad: string
  + atenderCliente(cliente: Cliente): void
  + mostrarHorariosDisponibles(): void
}

class Cita {
  - id_cita: int
  - fecha: date
  - hora: time
  - id_cliente: int
  - id_barbero: int
  + confirmarCita(): void
  + cancelarCita(): void
}

Cliente "1" -- "0..*" Cita : reserva
Barberia "1" -- "0..*" Barbero : tiene
Barbero "1" -- "0..*" Cita : atiende

@enduml
```

## Descripción de Clases

### Cliente
- **Atributos:**
  - id_cliente: Identificador único del cliente.
  - nombre: Nombre completo del cliente.
  - telefono: Número de teléfono del cliente.
  - email: Correo electrónico del cliente.

- **Métodos:**
  - registrarse(): Permite al cliente registrarse en el sistema.
  - reservarCita(): Permite al cliente reservar una cita.

### Barberia
- **Atributos:**
  - id_barberia: Identificador único de la barbería.
  - nombre: Nombre de la barbería.
  - direccion: Dirección de la barbería.
  - telefono: Número de contacto de la barbería.

- **Métodos:**
  - agregarBarbero(barbero: Barbero): Agrega un barbero a la barbería.
  - listarBarberos(): Muestra la lista de barberos disponibles.

### Barbero
- **Atributos:**
  - id_barbero: Identificador único del barbero.
  - nombre: Nombre completo del barbero.
  - especialidad: Especialidad del barbero (corte, afeitado, etc.).

- **Métodos:**
  - atenderCliente(cliente: Cliente): Atiende a un cliente.
  - mostrarHorariosDisponibles(): Muestra los horarios disponibles.

### Cita
- **Atributos:**
  - id_cita: Identificador único de la cita.
  - fecha: Fecha de la cita.
  - hora: Hora de la cita.
  - id_cliente: Referencia al cliente que realiza la cita.
  - id_barbero: Referencia al barbero que atenderá al cliente.

- **Métodos:**
  - confirmarCita(): Confirma la cita.
  - cancelarCita(): Cancela la cita.