# Diagrama de Secuencia de la barberia

---

```plantuml
@startuml

class Cliente {
  - id_cliente: int
  - nombre: string
  - telefono: string
  - email: string
  + registrarse(): void
  + reservarCita(): void
}

class Barberia {
  - id_barberia: int
  - nombre: string
  - direccion: string
  - telefono: string
  + agregarBarbero(barbero: Barbero): void
  + listarBarberos(): void
}

class Barbero {
  - id_barbero: int
  - nombre: string
  - especialidad: string
  + atenderCliente(cliente: Cliente): void
  + mostrarHorariosDisponibles(): void
}

class Cita {
  - id_cita: int
  - fecha: date
  - hora: time
  - id_cliente: int
  - id_barbero: int
  + confirmarCita(): void
  + cancelarCita(): void
}

Cliente "1" -- "0..*" Cita : reserva
Barberia "1" -- "0..*" Barbero : tiene
Barbero "1" -- "0..*" Cita : atiende

@enduml
```

## Descripción del Diagrama de Secuencia

### Proceso de Reserva de Cita:

1. **Registro de Cliente:**
   - El cliente llama al método `registrarse(nombre, telefono, email)`.
   - El sistema confirma el registro.

2. **Inicio de Sesión:**
   - El cliente llama al método `iniciarSesion(telefono)`.
   - El sistema valida las credenciales y envía una confirmación de inicio de sesión.

3. **Búsqueda de Barberos:**
   - El cliente solicita ver la lista de barberos disponibles.
   - El sistema devuelve la lista de barberos.

4. **Reserva de Cita:**
   - El cliente elige un barbero y llama al método `reservarCita(fecha, hora, id_barbero)`.
   - El sistema crea una nueva cita y confirma la acción.

5. **Confirmación de Cita:**
   - El sistema envía un mensaje de confirmación de la cita al cliente.