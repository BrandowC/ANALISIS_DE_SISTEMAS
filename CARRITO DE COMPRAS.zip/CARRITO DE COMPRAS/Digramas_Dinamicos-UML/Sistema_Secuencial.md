**Diagrama de Secuencia UML en Markdown**

Brandow S. Claros Polania

----

Se presenta el diagrama de secuencia que describe el proceso de agregar un producto al carrito y realizar la compra.

### Diagrama de Secuencia - Carrito de Compras

```plantuml
@startuml
Actor "Usuario"
participant "Carrito" as C
participant "Producto" as P
participant "Factura" as F
participant "DetalleFactura" as DF

Usuario -> C: agregarProducto(id_producto, cantidad)
C -> P: verificarDisponibilidad(id_producto, cantidad)
P --> C: disponibilidadConfirmada
C -> P: actualizarStock(id_producto, cantidad)
C -> C: calcularTotalCarrito()
Usuario -> C: revisarCarrito()
Usuario -> F: generarFactura()
F -> DF: agregarDetalle(id_producto, cantidad, precio)
F -> Usuario: enviarFactura()
@enduml

```

### Explicacion

- `Caso de Uso:` Agregar Producto al Carrito
- `Usuario:` Usuario
- `Descripción:` El usuario selecciona un producto y lo agrega a su carrito con una cantidad específica.
- `Flujo Principal:`
    - El usuario elige un producto y la cantidad deseada.
    - El sistema verifica la disponibilidad del producto.
    - Si hay suficiente stock, el sistema agrega el producto al carrito.

---

- `Caso de Uso:` Realizar Compra
- `Usuario:` Usuario
- `Descripción:` El usuario decide comprar los productos que están en su carrito.
- `Flujo Principal:`
    - El usuario revisa los productos en su carrito.
    - El sistema calcula el total de la compra.
    - El sistema genera una factura y la envía al usuario.

### Diagrama del Carrito de compras

![Diagrama_UML](Diagrama_Secuencia.png)

