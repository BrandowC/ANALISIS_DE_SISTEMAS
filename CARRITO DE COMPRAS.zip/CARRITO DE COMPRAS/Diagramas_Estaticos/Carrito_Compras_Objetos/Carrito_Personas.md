### Diagrama Uml - Carrito de Compras

```plantuml
@startuml

object Usuario {
    id_usuario: 1
    nombre_completo: "Juan Pérez"
    email: "juan.perez@example.com"
    telefono: "+123456789"
}

object Producto {
    id_producto: 101
    nombre_producto: "Laptop"
    descripcion: "Laptop de alto rendimiento"
    precio_unitario: 1200.0
}

object Carrito {
    id_carrito: 1001
    id_usuario: 1
    fecha_creacion: "2024-10-31"
}

object Factura {
    id_factura: 2001
    id_usuario: 1
    fecha_emision: "2024-10-31"
    total_factura: 1200.0
}

object DetalleFactura {
    id_detalle: 3001
    id_factura: 2001
    id_producto: 101
    cantidad: 1
    precio_total: 1200.0
}

Usuario -- Carrito
Usuario -- Factura
Factura -- DetalleFactura
Carrito -- Producto

@enduml

```

### Explicacion
---

- `Usuario:` Representa a un usuario específico con datos concretos.
- `Producto:` Representa un producto específico que se puede añadir al carrito.
- `Carrito:` Representa el carrito de compras de un usuario específico.
- `Factura:` Representa una factura generada para un usuario específico.
- `DetalleFactura:` Representa los detalles de la factura, vinculando el producto específico con la cantidad comprada.

![Diagrama_Carrito_Compras]()