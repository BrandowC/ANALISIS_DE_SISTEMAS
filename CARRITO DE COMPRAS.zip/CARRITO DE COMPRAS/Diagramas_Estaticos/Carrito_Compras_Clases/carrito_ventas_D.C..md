# SISTEMA DE COOMPRAS DE 

Brandow S. Claros Polania
---

Este sistemas que vamos a realizar se va llevar acabo diferentes clases de administrador con entidades  de Usuario, Producto,
Inventario, Detalle Factura y Factura.

## Diagrama de Clases

```plantuml
@startum

class Usuario {
    - id_usuario: entero
    - nombre_completo: cadena
    - email: cadena
    - telefono: cadena
    + Registrarse()
    + IniciarSesion()
}

class Producto {
    - id_producto: entero
    - nombre_producto: cadena
    - descripcion: cadena
    - precio_unitario: flotante
    + aplicarDescuento(descuento: flotante)
    + product_Disponible()
}

class Carrito {
    - id_carrito: entero
    - id_usuario: entero
    - fecha_creacion: fecha
    + agregarProducto(id_producto: entero, cantidad: entero)
    + eliminarProducto(id_producto: entero)
    + calcular_TotalCarrito(): flotante
}

class Factura {
    - id_factura: entero
    - id_usuario: entero
    - fecha_emision: fecha
    - total_factura: flotante
    + generar_Factura()
    + enviar_Factura(email: cadena)
}

class DetalleFactura {
    - id_detalle: entero
    - id_factura: enter
    - id_producto: entero
    - cantidad: entero
    - precio_total: flotante
    + calcular_PrecioTotal()
}

Usuario "1" --> "1..*" Carrito
Usuario "1" --> "1..*" Factura
Factura "1" --> "1..*" DetalleFactura
Carrito "1" --> "1..*" Producto
@enduml

```
# Descripción de Clases
**1. Usuario**
- **Atributos:**
    - `id_usuario`: Identificador único.
    - `nombre_completo`: Nombre completo del usuario.   
    - `email`: Dirección de correo electrónico.
    - `telefono`:Numero de contacto.

- **Método**  
    - `actualizarPerfil()`: Permite al usuario modificar sus datos.
    - `cerrarSesion()`: Cierra la sesión del usuario.

**2. Producto**
- **Atributos:**
    - `id_producto`: Identificador único del producto.
    - `nombre_producto`: Nombre del producto.
    - `descripcion`: Descripción detallada.
    - `precio_unitario`:Precio del producto.
- **Métodos:**
    - `aplicarDescuento(descuento: float)`: Aplica un descuento al precio.
    - `mostrarDisponibilidad()`: Muestra la disponibilidad del producto.

**3. Carrito**
- **Atributos:**
    - `id_carrito`: Identificador único del carrito.
    -`id_usuario`: Referencia al usuario propietario del carrito.
    - `fecha_creacion`: Fecha de creación del carrito.
- **Métodos:**
    - `agregarProducto(id_producto: entero, cantidad: entero)`: Agrega un producto al carrito.
    - `eliminarProducto(id_producto: entero)`: Elimina un producto del carrito.
    - `calcularTotalCarrito()`: Calcula el total del carrito.
    
**4. Factura**
- **Atributos:**
    - `id_factura`: Identificador único de la factura.
    - ``id_usuario``: Referencia al usuario que realizó la compra.
    - ``fecha_emision``: Fecha de emisión de la factura.
    - `total_factura`:Total a pagar.
- **Métodos:**
    - `generarFactura()`:Genera la factura.
    - `enviarFactura(email: String)`: Envía la factura al correo electrónico del usuario. 

**5. DetalleFactura**
- **Atributos:**
    - `id_detalle`: Identificador único del detalle.
    - `id_factura`: Referencia a la factura correspondiente.
    - `id_producto`: Referencia al producto.
    - `cantidad`:Cantidad vendida.
    - `precio_total`:Precio total del detalle.
- **Métodos:**
    - `calcularPrecioTotal():` Calcula el precio total del detalle.

## Imagen de Diagrama de clases 
![Diagrama](Diagrama_Clases.png)
